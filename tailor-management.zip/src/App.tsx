"use client"

import type React from "react"

import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { AuthProvider } from "./contexts/AuthContext"
import { AbilityProvider } from "./contexts/AbilityContext"
import { ThemeProvider } from "./components/theme-provider"
import LandingPage from "./pages/LandingPage"
import Dashboard from "./pages/Dashboard"
import LoginForm from "./components/auth/LoginForm"
import SignupForm from "./components/auth/SignupForm"
import ForgotPasswordForm from "./components/auth/ForgotPasswordForm"
import ProfileForm from "./components/profile/ProfileForm"
import OrderForm from "./components/orders/OrderForm"
import OrderList from "./components/orders/OrderList"
import OrderDetail from "./components/orders/OrderDetail"
import ChatList from "./components/chat/ChatList"
import ChatWindow from "./components/chat/ChatWindow"
import ReviewForm from "./components/reviews/ReviewForm"
import ReviewsPage from "./components/reviews/ReviewsPage"
import TailorsList from "./components/tailors/TailorsList"
import TailorProfile from "./components/tailors/TailorProfile"
import DashboardPage from "./components/dashboard/DashboardPage"
import AdminPage from "./components/admin/AdminPage"
import { useAuth } from "./contexts/AuthContext"

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { currentUser, loading } = useAuth()

  if (loading) {
    return <div>Loading...</div>
  }

  if (!currentUser) {
    return <Navigate to="/login" />
  }

  return <>{children}</>
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { userData, loading } = useAuth()

  if (loading) {
    return <div>Loading...</div>
  }

  if (!userData || userData.role !== "admin") {
    return <Navigate to="/dashboard" />
  }

  return <>{children}</>
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { currentUser, loading } = useAuth()

  if (loading) {
    return <div>Loading...</div>
  }

  if (currentUser) {
    return <Navigate to="/dashboard" />
  }

  return <>{children}</>
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />

      <Route
        path="/login"
        element={
          <PublicRoute>
            <div className="flex items-center justify-center min-h-screen bg-background">
              <LoginForm />
            </div>
          </PublicRoute>
        }
      />

      <Route
        path="/signup"
        element={
          <PublicRoute>
            <div className="flex items-center justify-center min-h-screen bg-background">
              <SignupForm />
            </div>
          </PublicRoute>
        }
      />

      <Route
        path="/forgot-password"
        element={
          <PublicRoute>
            <div className="flex items-center justify-center min-h-screen bg-background">
              <ForgotPasswordForm />
            </div>
          </PublicRoute>
        }
      />

      <Route
        path="/"
        element={
          <PrivateRoute>
            <Dashboard />
          </PrivateRoute>
        }
      >
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="profile" element={<ProfileForm />} />

        <Route path="orders" element={<OrderList />} />
        <Route path="orders/new" element={<OrderForm />} />
        <Route path="orders/:id" element={<OrderDetail />} />

        <Route path="chat" element={<ChatList />} />
        <Route path="chat/:id" element={<ChatWindow />} />

        <Route path="reviews/new" element={<ReviewForm />} />
        <Route path="reviews" element={<ReviewsPage />} />

        <Route path="tailors" element={<TailorsList />} />
        <Route path="tailors/:id" element={<TailorProfile />} />

        {/* <Route
          path="admin"
          element={
            <AdminRoute>
              <AdminPage />
            </AdminRoute>
          }
        /> */}
      </Route>

      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  )
}

export default function App() {
  return (
    <Router>
      <ThemeProvider defaultTheme="light" storageKey="tailor-connect-theme">
        <AuthProvider>
          <AbilityProvider>
            <AppRoutes />
          </AbilityProvider>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  )
}
