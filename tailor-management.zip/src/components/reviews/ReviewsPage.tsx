"use client"
import { useState, useEffect } from "react"
import { useAuth } from "../../contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Loader2, Star } from "lucide-react"
import { db } from "../../lib/firebase"
import { collection, query, where, orderBy, getDocs } from "firebase/firestore"
import type { Review } from "../../types"

export default function ReviewsPage() {
    const { userData } = useAuth()
    const [reviews, setReviews] = useState<Review[]>([])
    const [loading, setLoading] = useState(true)
    const [activeTab, setActiveTab] = useState("received")

    useEffect(() => {
        async function fetchReviews() {
            if (!userData) return

            try {
                let reviewsQuery

                if (activeTab === "received" && userData.role === "tailor") {
                    // Fetch reviews received by the tailor
                    reviewsQuery = query(
                        collection(db, "reviews"),
                        where("tailorId", "==", userData.id),
                        orderBy("createdAt", "desc"),
                    )
                } else {
                    // Fetch reviews given by the customer
                    reviewsQuery = query(
                        collection(db, "reviews"),
                        where("customerId", "==", userData.id),
                        orderBy("createdAt", "desc"),
                    )
                }

                const reviewsSnapshot = await getDocs(reviewsQuery)
                const reviewsData = reviewsSnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                    createdAt: doc.data().createdAt?.toDate() || new Date(),
                })) as Review[]

                setReviews(reviewsData)
                setLoading(false)
            } catch (err) {
                console.error("Error fetching reviews:", err)
                setLoading(false)
            }
        }

        fetchReviews()
    }, [userData, activeTab])

    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        )
    }

    return (
        <Card className="w-full">
            <CardHeader>
                <CardTitle className="text-2xl">Reviews</CardTitle>
                <CardDescription>
                    {userData?.role === "tailor" ? "View reviews from your customers" : "View reviews you've left for tailors"}
                </CardDescription>
            </CardHeader>
            <CardContent>
                {userData?.role === "tailor" ? (
                    <div className="space-y-6">
                        {reviews.length === 0 ? (
                            <div className="py-12 text-center">
                                <p className="text-muted-foreground">No reviews yet</p>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                <div className="flex items-center gap-4">
                                    <div className="flex items-center">
                                        {[1, 2, 3, 4, 5].map((value) => {
                                            const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
                                            return (
                                                <Star
                                                    key={value}
                                                    className={`h-5 w-5 ${value <= Math.round(averageRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                                        }`}
                                                />
                                            )
                                        })}
                                    </div>
                                    <div>
                                        <span className="font-medium">
                                            {(reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length).toFixed(1)}
                                        </span>
                                        <span className="ml-1 text-muted-foreground">({reviews.length} reviews)</span>
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    {reviews.map((review) => (
                                        <Card key={review.id}>
                                            <CardContent className="p-4">
                                                <div className="flex items-start gap-4">
                                                    <Avatar className="w-10 h-10">
                                                        <AvatarFallback>{review.customerName.charAt(0).toUpperCase()}</AvatarFallback>
                                                    </Avatar>
                                                    <div className="flex-1">
                                                        <div className="flex items-center justify-between">
                                                            <h4 className="font-medium">{review.customerName}</h4>
                                                            <span className="text-xs text-muted-foreground">
                                                                {review.createdAt.toLocaleDateString()}
                                                            </span>
                                                        </div>
                                                        <div className="flex my-1">
                                                            {[1, 2, 3, 4, 5].map((value) => (
                                                                <Star
                                                                    key={value}
                                                                    className={`h-4 w-4 ${value <= review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                                                        }`}
                                                                />
                                                            ))}
                                                        </div>
                                                        <p className="mt-2 text-muted-foreground">{review.comment}</p>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="space-y-6">
                        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                            <TabsList className="grid w-full grid-cols-2">
                                <TabsTrigger value="given">Reviews Given</TabsTrigger>
                                <TabsTrigger value="received">Reviews Received</TabsTrigger>
                            </TabsList>
                        </Tabs>

                        {reviews.length === 0 ? (
                            <div className="py-12 text-center">
                                <p className="text-muted-foreground">
                                    {activeTab === "given" ? "You haven't given any reviews yet" : "You haven't received any reviews yet"}
                                </p>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {reviews.map((review) => (
                                    <Card key={review.id}>
                                        <CardContent className="p-4">
                                            <div className="flex items-start gap-4">
                                                <Avatar className="w-10 h-10">
                                                    <AvatarFallback>
                                                        {activeTab === "given"
                                                            ? review.tailorName.charAt(0).toUpperCase()
                                                            : review.customerName.charAt(0).toUpperCase()}
                                                    </AvatarFallback>
                                                </Avatar>
                                                <div className="flex-1">
                                                    <div className="flex items-center justify-between">
                                                        <h4 className="font-medium">
                                                            {activeTab === "given" ? review.tailorName : review.customerName}
                                                        </h4>
                                                        <span className="text-xs text-muted-foreground">
                                                            {review.createdAt.toLocaleDateString()}
                                                        </span>
                                                    </div>
                                                    <div className="flex my-1">
                                                        {[1, 2, 3, 4, 5].map((value) => (
                                                            <Star
                                                                key={value}
                                                                className={`h-4 w-4 ${value <= review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                                                    }`}
                                                            />
                                                        ))}
                                                    </div>
                                                    <p className="mt-2 text-muted-foreground">{review.comment}</p>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    )
}
