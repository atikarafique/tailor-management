"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { useNavigate, useLocation } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Star } from "lucide-react"
import { db } from "../../lib/firebase"
import { doc, getDoc, addDoc, collection, serverTimestamp } from "firebase/firestore"
import type { Order, User } from "../../types"

export default function ReviewForm() {
  const { userData } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const queryParams = new URLSearchParams(location.search)
  const orderId = queryParams.get("orderId")
  const tailorId = queryParams.get("tailorId")

  const [order, setOrder] = useState<Order | null>(null)
  const [tailor, setTailor] = useState<User | null>(null)
  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    async function fetchData() {
      if (!orderId || !tailorId) {
        setError("Missing order or tailor information")
        setLoading(false)
        return
      }

      try {
        // Fetch order
        const orderDoc = await getDoc(doc(db, "orders", orderId))
        if (!orderDoc.exists()) {
          setError("Order not found")
          setLoading(false)
          return
        }

        const orderData = {
          id: orderDoc.id,
          ...orderDoc.data(),
          createdAt: orderDoc.data().createdAt?.toDate() || new Date(),
          updatedAt: orderDoc.data().updatedAt?.toDate() || new Date(),
        } as Order

        // Verify this is the customer's order and it's completed
        if (orderData.customerId !== userData?.id) {
          setError("You can only review your own orders")
          setLoading(false)
          return
        }

        if (orderData.status !== "completed") {
          setError("You can only review completed orders")
          setLoading(false)
          return
        }

        setOrder(orderData)

        // Fetch tailor
        const tailorDoc = await getDoc(doc(db, "users", tailorId))
        if (!tailorDoc.exists()) {
          setError("Tailor not found")
          setLoading(false)
          return
        }

        setTailor(tailorDoc.data() as User)
        setLoading(false)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load data")
        setLoading(false)
      }
    }

    fetchData()
  }, [orderId, tailorId, userData?.id])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userData || !order || !tailor) {
      setError("Missing required information")
      return
    }

    if (rating === 0) {
      setError("Please select a rating")
      return
    }

    try {
      setSubmitting(true)
      setError("")

      await addDoc(collection(db, "reviews"), {
        orderId: order.id,
        customerId: userData.id,
        customerName: userData.displayName,
        tailorId: tailor.id,
        rating,
        comment,
        createdAt: serverTimestamp(),
      })

      navigate(`/tailors/${tailor.id}`)
    } catch (err) {
      console.error("Error submitting review:", err)
      setError("Failed to submit review")
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="text-2xl">Leave a Review</CardTitle>
        <CardDescription>Share your experience with {tailor?.displayName}</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-4">Rating</h3>
            <div className="flex items-center space-x-2">
              {[1, 2, 3, 4, 5].map((value) => (
                <button key={value} type="button" onClick={() => setRating(value)} className="focus:outline-none">
                  <Star
                    className={`h-8 w-8 ${value <= rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-medium">Your Review</h3>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={6}
              placeholder="Share your experience with this tailor..."
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : (
              "Submit Review"
            )}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex justify-center text-sm text-muted-foreground">
        Your review helps other customers find great tailors.
      </CardFooter>
    </Card>
  )
}
