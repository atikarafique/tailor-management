"use client"
import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Loader2, Star } from "lucide-react"
import { db } from "../../lib/firebase"
import { collection, query, where, orderBy, getDocs } from "firebase/firestore"
import type { Review } from "../../types"

interface ReviewListProps {
  tailorId: string
}

export default function ReviewList({ tailorId }: ReviewListProps) {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [averageRating, setAverageRating] = useState(0)

  useEffect(() => {
    async function fetchReviews() {
      try {
        const reviewsQuery = query(
          collection(db, "reviews"),
          where("tailorId", "==", tailorId),
          orderBy("createdAt", "desc"),
        )

        const reviewsSnapshot = await getDocs(reviewsQuery)
        const reviewsData = reviewsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate() || new Date(),
        })) as Review[]

        setReviews(reviewsData)

        // Calculate average rating
        if (reviewsData.length > 0) {
          const total = reviewsData.reduce((sum, review) => sum + review.rating, 0)
          setAverageRating(total / reviewsData.length)
        }

        setLoading(false)
      } catch (err) {
        console.error("Error fetching reviews:", err)
        setLoading(false)
      }
    }

    fetchReviews()
  }, [tailorId])

  if (loading) {
    return (
      <div className="flex justify-center items-center h-32">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    )
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No reviews yet</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <div className="flex items-center">
          {[1, 2, 3, 4, 5].map((value) => (
            <Star
              key={value}
              className={`h-5 w-5 ${
                value <= Math.round(averageRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
              }`}
            />
          ))}
        </div>
        <div>
          <span className="font-medium">{averageRating.toFixed(1)}</span>
          <span className="text-muted-foreground ml-1">({reviews.length} reviews)</span>
        </div>
      </div>

      <div className="space-y-4">
        {reviews.map((review) => (
          <Card key={review.id}>
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <Avatar className="h-10 w-10">
                  <AvatarFallback>{review.customerName.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{review.customerName}</h4>
                    <span className="text-xs text-muted-foreground">{review.createdAt.toLocaleDateString()}</span>
                  </div>
                  <div className="flex my-1">
                    {[1, 2, 3, 4, 5].map((value) => (
                      <Star
                        key={value}
                        className={`h-4 w-4 ${
                          value <= review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-muted-foreground mt-2">{review.comment}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
