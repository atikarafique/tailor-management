import { CheckCircle, Scissors, Ruler, MessageSquare, Star, Clock } from "lucide-react"

export default function Features() {
  const features = [
    {
      icon: <Scissors className="h-10 w-10 text-primary" />,
      title: "Expert Tailors",
      description: "Connect with skilled tailors specializing in traditional Pakistani clothing and modern designs.",
    },
    {
      icon: <Ruler className="h-10 w-10 text-primary" />,
      title: "Custom Measurements",
      description: "Provide detailed measurements for perfectly fitted garments tailored to your body.",
    },
    {
      icon: <MessageSquare className="h-10 w-10 text-primary" />,
      title: "Direct Communication",
      description: "Chat directly with your tailor to discuss designs, fabrics, and special requirements.",
    },
    {
      icon: <Star className="h-10 w-10 text-primary" />,
      title: "Quality Reviews",
      description: "Read and leave reviews to ensure you work with the best tailors in the business.",
    },
    {
      icon: <Clock className="h-10 w-10 text-primary" />,
      title: "Order Tracking",
      description: "Track your order status from acceptance to completion in real-time.",
    },
    {
      icon: <CheckCircle className="h-10 w-10 text-primary" />,
      title: "Satisfaction Guaranteed",
      description: "We ensure your complete satisfaction with every garment and service.",
    },
  ]

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Our Platform</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We connect customers with skilled tailors to create beautiful, custom-fitted clothing
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-card p-6 rounded-lg shadow-sm border border-border hover:shadow-md transition-shadow"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
