import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Link } from "react-router-dom"

export default function ClothingShowcase() {
  const clothingTypes = [
    {
      name: "Shalwar Kameez",
      description: "Traditional Pakistani outfit consisting of a tunic top and loose-fitting pants",
      image: "/vibrant-shalwar-kameez.png",
    },
    {
      name: "Kurta",
      description: "A loose collarless shirt worn in many regions of South Asia",
      image: "/elegant-embroidered-kurta.png",
    },
    {
      name: "Sherwani",
      description: "A long coat-like garment worn for formal occasions in South Asia",
      image: "/elegant-sherwani.png",
    },
    {
      name: "Lehenga",
      description: "A traditional floor length skirt often paired with a choli and dupatta",
      image: "/vibrant-silk-lehenga.png",
    },
  ]

  return (
    <section className="py-20 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Traditional Pakistani Clothing</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our range of traditional Pakistani clothing options, all customizable to your measurements
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {clothingTypes.map((clothing, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-[3/4] relative">
                <img
                  src={clothing.image || "/placeholder.svg"}
                  alt={clothing.name}
                  className="object-cover w-full h-full"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="text-xl font-semibold mb-2">{clothing.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">{clothing.description}</p>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/order">Order Now</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button asChild size="lg">
            <Link to="/clothing-types">View All Clothing Types</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
