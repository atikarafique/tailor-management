import { Button } from "@/components/ui/button"
import { Link } from "react-router-dom"

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-primary/20 to-background py-20">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 space-y-6 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
              <span className="block">Custom Tailoring</span>
              <span className="block text-primary">Made Simple</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto lg:mx-0">
              Connect with skilled tailors, order custom Pakistani clothing, and manage your orders all in one place.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button asChild size="lg" className="text-base">
                <Link to="/signup">Get Started</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="text-base">
                <Link to="/tailors">Find Tailors</Link>
              </Button>
            </div>
          </div>
          <div className="flex-1">
            <img
              src="/skilled-pakistani-tailor.png"
              alt="Tailor crafting traditional clothing"
              className="rounded-lg shadow-2xl w-full max-w-lg mx-auto"
            />
          </div>
        </div>
      </div>
      <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
    </div>
  )
}
