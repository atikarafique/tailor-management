import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star } from "lucide-react"

export default function Testimonials() {
  const testimonials = [
    {
      name: "Ahmed Khan",
      avatar: "/placeholder.svg?height=100&width=100&query=smiling man with beard",
      role: "Customer",
      content:
        "I ordered a Sherwani for my wedding and it exceeded all my expectations. The fit was perfect and the craftsmanship was exceptional. Highly recommend!",
      rating: 5,
    },
    {
      name: "Fatima Ali",
      avatar: "/placeholder.svg?height=100&width=100&query=smiling woman with hijab",
      role: "Customer",
      content:
        "The Shalwar Kameez I ordered was beautifully made. The tailor was very communicative and made adjustments exactly as I requested. Will definitely order again.",
      rating: 5,
    },
    {
      name: "Zainab Malik",
      avatar: "/placeholder.svg?height=100&width=100&query=professional woman",
      role: "Customer",
      content:
        "I've tried many tailoring services, but this platform is by far the best. The quality of work and attention to detail is outstanding.",
      rating: 4,
    },
  ]

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="h-full">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex items-center mb-4">
                  <Avatar className="h-12 w-12 mr-4">
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold">{testimonial.name}</h3>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < testimonial.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                    />
                  ))}
                </div>
                <p className="text-muted-foreground flex-grow">{testimonial.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
