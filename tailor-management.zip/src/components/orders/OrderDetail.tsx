"use client"
import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { useAbility } from "../../contexts/AbilityContext"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Loader2, ArrowLeft, MessageSquare, Star } from "lucide-react"
import { db } from "../../lib/firebase"
import { doc, getDoc, updateDoc, serverTimestamp } from "firebase/firestore"
import type { Order } from "../../types"
import { Link } from "react-router-dom"

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>()
  const { userData } = useAuth()
  const ability = useAbility()
  const navigate = useNavigate()
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [updating, setUpdating] = useState(false)
  const [status, setStatus] = useState("")
  const [price, setPrice] = useState("")
  const [notes, setNotes] = useState("")

  useEffect(() => {
    async function fetchOrder() {
      if (!id) return

      try {
        const orderDoc = await getDoc(doc(db, "orders", id))

        if (!orderDoc.exists()) {
          setError("Order not found")
          setLoading(false)
          return
        }

        const orderData = {
          id: orderDoc.id,
          ...orderDoc.data(),
          createdAt: orderDoc.data().createdAt?.toDate() || new Date(),
          updatedAt: orderDoc.data().updatedAt?.toDate() || new Date(),
        } as Order

        setOrder(orderData)
        setStatus(orderData.status)
        setPrice(orderData.price.toString())
        setNotes(orderData.notes || "")
        setLoading(false)
      } catch (err) {
        console.error("Error fetching order:", err)
        setError("Failed to load order details")
        setLoading(false)
      }
    }

    fetchOrder()
  }, [id])

  const handleUpdateOrder = async () => {
    if (!order || !id) return

    try {
      setUpdating(true)

      const updates: Partial<Order> = {
        updatedAt: new Date(),
      }

      if (userData?.role === "tailor") {
        updates.status = status
        updates.price = Number.parseFloat(price) || 0
      } else if (userData?.role === "customer") {
        // Customers can only cancel orders
        if (status === "cancelled") {
          updates.status = status
        }
      }

      if (notes !== order.notes) {
        updates.notes = notes
      }

      await updateDoc(doc(db, "orders", id), {
        ...updates,
        updatedAt: serverTimestamp(),
      })

      // Refresh order data
      const updatedOrderDoc = await getDoc(doc(db, "orders", id))
      const updatedOrderData = {
        id: updatedOrderDoc.id,
        ...updatedOrderDoc.data(),
        createdAt: updatedOrderDoc.data().createdAt?.toDate() || new Date(),
        updatedAt: updatedOrderDoc.data().updatedAt?.toDate() || new Date(),
      } as Order

      setOrder(updatedOrderData)
      setUpdating(false)
    } catch (err) {
      console.error("Error updating order:", err)
      setError("Failed to update order")
      setUpdating(false)
    }
  }

  const canUpdateStatus = () => {
    if (!userData || !order) return false

    if (userData.role === "tailor" && order.tailorId === userData.id) {
      return true
    }

    if (userData.role === "customer" && order.customerId === userData.id) {
      // Customers can only cancel pending orders
      return order.status === "pending"
    }

    return false
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!order) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Order not found</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/orders">Back to Orders</Link>
        </Button>
      </div>
    )
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "accepted":
        return "default"
      case "in-progress":
        return "default"
      case "completed":
        return "success"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <div className="flex items-center mb-2">
          <Button variant="ghost" size="sm" asChild className="mr-2">
            <Link to="/orders">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back
            </Link>
          </Button>
          <Badge variant={getStatusBadgeVariant(order.status)}>
            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
          </Badge>
        </div>
        <CardTitle className="text-2xl">{order.clothingType}</CardTitle>
        <CardDescription>
          Order #{order.id.substring(0, 8)} • Placed on {order.createdAt.toLocaleDateString()}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium mb-2">Order Details</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Customer:</span>
                <span>{order.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tailor:</span>
                <span>{order.tailorName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Price:</span>
                <span>{order.price > 0 ? `$${order.price.toFixed(2)}` : "To be determined"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Last Updated:</span>
                <span>{order.updatedAt.toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-2">Measurements</h3>
            <div className="space-y-2">
              {Object.entries(order.measurements).map(([key, value]) => (
                <div key={key} className="flex justify-between">
                  <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, " $1").trim()}:</span>
                  <span>{value} inches</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <Separator />

        {canUpdateStatus() && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Update Order</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {userData?.role === "tailor" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select value={status} onValueChange={setStatus}>
                      <SelectTrigger id="status">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="accepted">Accepted</SelectItem>
                        <SelectItem value="in-progress">In Progress</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">Price ($)</Label>
                    <input
                      id="price"
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                </>
              )}

              {userData?.role === "customer" && order.status === "pending" && (
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="cancelled">Cancel Order</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} />
            </div>

            <Button onClick={handleUpdateOrder} disabled={updating}>
              {updating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : (
                "Update Order"
              )}
            </Button>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-4 justify-between">
        <Button variant="outline" asChild>
          <Link to={`/chat/${order.customerId}_${order.tailorId}`}>
            <MessageSquare className="mr-2 h-4 w-4" />
            Chat with {userData?.role === "customer" ? "Tailor" : "Customer"}
          </Link>
        </Button>

        {userData?.role === "customer" && order.status === "completed" && (
          <Button asChild>
            <Link to={`/reviews/new?orderId=${order.id}&tailorId=${order.tailorId}`}>
              <Star className="mr-2 h-4 w-4" />
              Leave a Review
            </Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
