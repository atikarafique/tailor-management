"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { useNavigate } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2 } from "lucide-react"
import { db } from "../../lib/firebase"
import { collection, getDocs, query, where, addDoc, serverTimestamp } from "firebase/firestore"
import type { ClothingType, User } from "../../types"

export default function OrderForm() {
  const { userData } = useAuth()
  const navigate = useNavigate()
  const [clothingTypes, setClothingTypes] = useState<ClothingType[]>([
    {
      id: "shalwar-kameez-01",
      name: "Traditional Shalwar Kameez",
      category: "Traditional Wear",
      description: "A classic Pakistani/Indian outfit consisting of a long tunic (kameez) paired with loose trousers (shalwar) and a dupatta.",
      imageUrl: "https://example.com/images/shalwar-kameez.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "chestAround",
        "waistAround",
        "hipsAround",
        "armLength",
        "kameezLength",
        "shalwarLength",
        "ankleAround"
      ]
    },
    {
      id: "suit-01",
      name: "Formal Suit",
      category: "Formal Wear",
      description: "A tailored two-piece or three-piece formal suit for professional or special occasions.",
      imageUrl: "https://example.com/images/formal-suit.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "chestAround",
        "waistAround",
        "jacketLength",
        "sleeveLength",
        "pantsWaist",
        "pantsLength",
        "pantsInseam"
      ]
    },
    {
      id: "jeans-01",
      name: "Fitted Jeans",
      category: "Casual Wear",
      description: "Classic denim jeans with a tailored fit.",
      imageUrl: "https://example.com/images/jeans.jpg",
      requiredMeasurements: [
        "waistAround",
        "hipsAround",
        "thighAround",
        "kneeAround",
        "ankleAround",
        "pantsLength",
        "pantsInseam"
      ]
    },
    {
      id: "kurta-01",
      name: "Men's Kurta",
      category: "Traditional Wear",
      description: "A long loose shirt worn by men in South Asia, typically with pajama or churidar.",
      imageUrl: "https://example.com/images/mens-kurta.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "chestAround",
        "waistAround",
        "hipsAround",
        "armLength",
        "kurtaLength",
        "neckAround"
      ]
    },
    {
      id: "lehenga-01",
      name: "Bridal Lehenga",
      category: "Wedding Wear",
      description: "An elaborate embroidered skirt with blouse and dupatta for bridal occasions.",
      imageUrl: "https://example.com/images/lehenga.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "bustAround",
        "waistAround",
        "hipsAround",
        "blouseLength",
        "lehengaLength",
        "armLength"
      ]
    },
    {
      id: "sherwani-01",
      name: "Wedding Sherwani",
      category: "Wedding Wear",
      description: "A long coat-like garment worn by South Asian grooms, often heavily embroidered.",
      imageUrl: "https://example.com/images/sherwani.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "chestAround",
        "waistAround",
        "hipsAround",
        "armLength",
        "sherwaniLength",
        "neckAround"
      ]
    },
    {
      id: "abaya-01",
      name: "Traditional Abaya",
      category: "Islamic Wear",
      description: "A long flowing outer garment worn by women in some Muslim countries.",
      imageUrl: "https://example.com/images/abaya.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "bustAround",
        "waistAround",
        "hipsAround",
        "armLength",
        "dressLength"
      ]
    },
    {
      id: "churidar-01",
      name: "Churidar Suit",
      category: "Traditional Wear",
      description: "A kameez paired with tightly fitting trousers that gather at the ankle.",
      imageUrl: "https://example.com/images/churidar.jpg",
      requiredMeasurements: [
        "shoulderWidth",
        "chestAround",
        "waistAround",
        "hipsAround",
        "armLength",
        "kameezLength",
        "churidarLength",
        "ankleAround"
      ]
    }
  ]
  )
  const [tailors, setTailors] = useState<User[]>([])
  const [selectedClothingType, setSelectedClothingType] = useState("")
  const [selectedTailor, setSelectedTailor] = useState("")
  const [measurements, setMeasurements] = useState<Record<string, number>>({})
  const [notes, setNotes] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [loadingData, setLoadingData] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        // Fetch clothing types
        // const clothingSnapshot = await getDocs(collection(db, "clothingTypes"))
        // const clothingData = clothingSnapshot.docs.map((doc) => ({
        //   id: doc.id,
        //   ...doc.data(),
        // })) as ClothingType[]
        // setClothingTypes(clothingData)

        // Fetch tailors
        const tailorsQuery = query(collection(db, "users"), where("role", "==", "tailor"))
        const tailorsSnapshot = await getDocs(tailorsQuery)
        const tailorsData = tailorsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as User[]
        setTailors(tailorsData)

        setLoadingData(false)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load data. Please try again.")
        setLoadingData(false)
      }
    }

    fetchData()
  }, [])

  const handleMeasurementChange = (field: string, value: string) => {
    const numValue = Number.parseFloat(value)
    if (!isNaN(numValue)) {
      setMeasurements((prev) => ({
        ...prev,
        [field]: numValue,
      }))
    } else if (value === "") {
      // Allow empty field for clearing
      const newMeasurements = { ...measurements }
      delete newMeasurements[field]
      setMeasurements(newMeasurements)
    }
  }

  const getRequiredMeasurements = () => {
    const clothingType = clothingTypes.find((type) => type.id === selectedClothingType)
    return clothingType?.requiredMeasurements || []
  }

  const validateMeasurements = () => {
    const required = getRequiredMeasurements()
    return required.every((field) => measurements[field] !== undefined)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userData) {
      setError("You must be logged in to place an order")
      return
    }

    if (!selectedClothingType) {
      setError("Please select a clothing type")
      return
    }

    if (!selectedTailor) {
      setError("Please select a tailor")
      return
    }

    if (!validateMeasurements()) {
      setError("Please provide all required measurements")
      return
    }

    try {
      setLoading(true)
      setError("")

      const clothingType = clothingTypes.find((type) => type.id === selectedClothingType)
      const tailor = tailors.find((tailor) => tailor.id === selectedTailor)

      if (!clothingType || !tailor) {
        throw new Error("Invalid selection")
      }

      const orderData = {
        customerId: userData.id,
        customerName: userData.displayName,
        tailorId: tailor.id,
        tailorName: tailor.displayName,
        clothingType: clothingType.name,
        measurements,
        status: "pending",
        price: 0, // To be set by tailor
        notes,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }

      const orderRef = await addDoc(collection(db, "orders"), orderData)

      navigate(`/orders/${orderRef.id}`)
    } catch (err) {
      console.error("Error placing order:", err)
      setError("Failed to place order. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (loadingData) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <CardTitle className="text-2xl">Place a New Order</CardTitle>
        <CardDescription>Select your clothing type, tailor, and provide your measurements</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="clothing-type">Clothing Type</Label>
              <Select value={selectedClothingType} onValueChange={setSelectedClothingType}>
                <SelectTrigger id="clothing-type">
                  <SelectValue placeholder="Select clothing type" />
                </SelectTrigger>
                <SelectContent>
                  {clothingTypes.map((type) => {
                    return (
                      <SelectItem key={type.id} value={type.id}>
                        {type.name}
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tailor">Tailor</Label>
              <Select value={selectedTailor} onValueChange={setSelectedTailor}>
                <SelectTrigger id="tailor">
                  <SelectValue placeholder="Select tailor" />
                </SelectTrigger>
                <SelectContent>
                  {tailors.map((tailor) => (
                    <SelectItem key={tailor.id} value={tailor.id}>
                      {tailor.displayName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedClothingType && (
            <Tabs defaultValue="measurements" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="measurements">Measurements</TabsTrigger>
                <TabsTrigger value="notes">Additional Notes</TabsTrigger>
              </TabsList>
              <TabsContent value="measurements" className="pt-4 space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
                  {getRequiredMeasurements().map((field) => (
                    <div key={field} className="space-y-2">
                      <Label htmlFor={field} className="capitalize">
                        {field.replace(/([A-Z])/g, " $1").trim()} (inches)
                      </Label>
                      <Input
                        id={field}
                        type="number"
                        step="0.1"
                        value={measurements[field] || ""}
                        onChange={(e) => handleMeasurementChange(field, e.target.value)}
                        required
                      />
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="notes" className="pt-4 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="notes">Special Instructions or Requirements</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={6}
                    placeholder="Add any special instructions, fabric preferences, design details, or other requirements here..."
                  />
                </div>
              </TabsContent>
            </Tabs>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Placing Order...
              </>
            ) : (
              "Place Order"
            )}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex justify-center text-sm text-muted-foreground">
        Your order will be sent to the tailor for review and pricing before it's confirmed.
      </CardFooter>
    </Card>
  )
}
