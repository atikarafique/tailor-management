"use client"
import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { useAbility } from "../../contexts/AbilityContext"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Loader2, Plus, Search } from "lucide-react"
import { db } from "../../lib/firebase"
import { collection, getDocs, query, where, orderBy } from "firebase/firestore"
import type { Order } from "../../types"
import { Input } from "@/components/ui/input"

export default function OrderList() {
  const { userData } = useAuth()
  const ability = useAbility()
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    async function fetchOrders() {
      if (!userData) return

      try {
        let ordersQuery

        if (userData.role === "customer") {
          ordersQuery = query(
            collection(db, "orders"),
            where("customerId", "==", userData.id),
            orderBy("createdAt", "desc"),
          )
        } else if (userData.role === "tailor") {
          ordersQuery = query(
            collection(db, "orders"),
            where("tailorId", "==", userData.id),
            orderBy("createdAt", "desc"),
          )
        } else {
          // Admin can see all orders
          ordersQuery = query(collection(db, "orders"), orderBy("createdAt", "desc"))
        }

        const ordersSnapshot = await getDocs(ordersQuery)
        const ordersData = ordersSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate() || new Date(),
          updatedAt: doc.data().updatedAt?.toDate() || new Date(),
        })) as Order[]

        setOrders(ordersData)
        setFilteredOrders(ordersData)
        setLoading(false)
      } catch (err) {
        console.error("Error fetching orders:", err)
        setLoading(false)
      }
    }

    fetchOrders()
  }, [userData])

  useEffect(() => {
    // Filter orders based on search term and active tab
    let filtered = orders

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (order) =>
          order.clothingType.toLowerCase().includes(term) ||
          (userData?.role === "tailor"
            ? order.customerName.toLowerCase().includes(term)
            : order.tailorName.toLowerCase().includes(term)),
      )
    }

    // Filter by status
    if (activeTab !== "all") {
      filtered = filtered.filter((order) => order.status === activeTab)
    }

    setFilteredOrders(filtered)
  }, [searchTerm, activeTab, orders, userData?.role])

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "accepted":
        return "default"
      case "in-progress":
        return "default"
      case "completed":
        return "success"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <CardTitle className="text-2xl">Your Orders</CardTitle>
            <CardDescription>
              {userData?.role === "customer"
                ? "View and manage your clothing orders"
                : "View and manage orders from your customers"}
            </CardDescription>
          </div>
          {ability.can("create", "Order") && (
            <Button asChild>
              <Link to="/orders/new">
                <Plus className="mr-2 h-4 w-4" />
                New Order
              </Link>
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search orders..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
              <TabsList className="grid grid-cols-5 w-full sm:w-auto">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="accepted">Accepted</TabsTrigger>
                <TabsTrigger value="in-progress">In Progress</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No orders found</p>
              {ability.can("create", "Order") && (
                <Button asChild variant="outline" className="mt-4">
                  <Link to="/orders/new">Place your first order</Link>
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <Link key={order.id} to={`/orders/${order.id}`} className="block">
                  <div className="border rounded-lg p-4 hover:border-primary transition-colors">
                    <div className="flex flex-col sm:flex-row justify-between gap-4">
                      <div>
                        <h3 className="font-medium">{order.clothingType}</h3>
                        <p className="text-sm text-muted-foreground">
                          {userData?.role === "customer"
                            ? `Tailor: ${order.tailorName}`
                            : `Customer: ${order.customerName}`}
                        </p>
                      </div>
                      <div className="flex flex-col sm:items-end gap-2">
                        <Badge variant={getStatusBadgeVariant(order.status)}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                        <p className="text-xs text-muted-foreground">
                          Ordered on {order.createdAt.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
