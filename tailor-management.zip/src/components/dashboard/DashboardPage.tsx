"use client"
import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Loader2, ShoppingBag, MessageSquare, Star, TrendingUp, Clock } from "lucide-react"
import { db } from "../../lib/firebase"
import { collection, query, where, getDocs, orderBy, limit, Timestamp } from "firebase/firestore"
import type { Order, Review, User, Chat } from "../../types"

export default function DashboardPage() {
    const { userData } = useAuth()
    const [loading, setLoading] = useState(true)
    const [stats, setStats] = useState({
        totalOrders: 0,
        pendingOrders: 0,
        completedOrders: 0,
        totalRevenue: 0,
        averageRating: 0,
        unreadMessages: 0,
    })
    const [recentOrders, setRecentOrders] = useState<Order[]>([])
    const [recentReviews, setRecentReviews] = useState<Review[]>([])
    const [popularTailors, setPopularTailors] = useState<User[]>([])
    const [timeframe, setTimeframe] = useState<"week" | "month" | "year">("month")

    useEffect(() => {
        async function fetchDashboardData() {
            if (!userData) return

            try {
                // Calculate date range based on timeframe
                const now = new Date()
                const startDate = new Date()

                if (timeframe === "week") {
                    startDate.setDate(now.getDate() - 7)
                } else if (timeframe === "month") {
                    startDate.setMonth(now.getMonth() - 1)
                } else {
                    startDate.setFullYear(now.getFullYear() - 1)
                }

                const startTimestamp = Timestamp.fromDate(startDate)

                // Fetch orders
                let ordersQuery
                if (userData.role === "customer") {
                    ordersQuery = query(
                        collection(db, "orders"),
                        where("customerId", "==", userData.id),
                        orderBy("createdAt", "desc"),
                    )
                } else if (userData.role === "tailor") {
                    ordersQuery = query(
                        collection(db, "orders"),
                        where("tailorId", "==", userData.id),
                        orderBy("createdAt", "desc"),
                    )
                } else {
                    // Admin can see all orders
                    ordersQuery = query(collection(db, "orders"), orderBy("createdAt", "desc"))
                }

                const ordersSnapshot = await getDocs(ordersQuery)
                const ordersData = ordersSnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                    createdAt: doc.data().createdAt?.toDate() || new Date(),
                    updatedAt: doc.data().updatedAt?.toDate() || new Date(),
                })) as Order[]

                // Filter orders by timeframe
                const filteredOrders = ordersData.filter((order) => order.createdAt >= startDate)

                // Calculate order stats
                const totalOrders = filteredOrders.length
                const pendingOrders = filteredOrders.filter(
                    (order) => order.status === "pending" || order.status === "accepted" || order.status === "in-progress",
                ).length
                const completedOrders = filteredOrders.filter((order) => order.status === "completed").length
                const totalRevenue = filteredOrders
                    .filter((order) => order.status === "completed")
                    .reduce((sum, order) => sum + order.price, 0)

                // Set recent orders
                setRecentOrders(ordersData.slice(0, 5))

                // Fetch reviews
                let reviewsQuery
                if (userData.role === "customer") {
                    reviewsQuery = query(
                        collection(db, "reviews"),
                        where("customerId", "==", userData.id),
                        orderBy("createdAt", "desc"),
                        limit(3),
                    )
                } else if (userData.role === "tailor") {
                    reviewsQuery = query(
                        collection(db, "reviews"),
                        where("tailorId", "==", userData.id),
                        orderBy("createdAt", "desc"),
                        limit(3),
                    )
                } else {
                    reviewsQuery = query(collection(db, "reviews"), orderBy("createdAt", "desc"), limit(3))
                }

                const reviewsSnapshot = await getDocs(reviewsQuery)
                const reviewsData = reviewsSnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                    createdAt: doc.data().createdAt?.toDate() || new Date(),
                })) as Review[]

                setRecentReviews(reviewsData)

                // Calculate average rating for tailors
                let averageRating = 0
                if (userData.role === "tailor") {
                    const allReviewsQuery = query(collection(db, "reviews"), where("tailorId", "==", userData.id))
                    const allReviewsSnapshot = await getDocs(allReviewsQuery)
                    const allReviews = allReviewsSnapshot.docs.map((doc) => doc.data())

                    if (allReviews.length > 0) {
                        const totalRating = allReviews.reduce((sum, review) => sum + (review.rating || 0), 0)
                        averageRating = totalRating / allReviews.length
                    }
                }

                // Fetch unread messages
                let unreadMessages = 0
                if (userData.role === "customer" || userData.role === "tailor") {
                    const chatsQuery = query(collection(db, "chats"), where("participants", "array-contains", userData.id))
                    const chatsSnapshot = await getDocs(chatsQuery)
                    const chatsData = chatsSnapshot.docs.map((doc) => ({
                        id: doc.id,
                        ...doc.data(),
                    })) as Chat[]

                    unreadMessages = chatsData.reduce((sum, chat) => sum + (chat.unreadCount?.[userData.id] || 0), 0)
                }

                // Fetch popular tailors (for customers)
                if (userData.role === "customer" || userData.role === "admin") {
                    const tailorsQuery = query(collection(db, "users"), where("role", "==", "tailor"), limit(3))
                    const tailorsSnapshot = await getDocs(tailorsQuery)
                    const tailorsData = tailorsSnapshot.docs.map((doc) => ({
                        id: doc.id,
                        ...doc.data(),
                    })) as User[]

                    // For each tailor, fetch their average rating
                    const tailorsWithRatings = await Promise.all(
                        tailorsData.map(async (tailor) => {
                            const tailerReviewsQuery = query(collection(db, "reviews"), where("tailorId", "==", tailor.id))
                            const tailerReviewsSnapshot = await getDocs(tailerReviewsQuery)
                            const tailerReviews = tailerReviewsSnapshot.docs.map((doc) => doc.data())

                            let rating = 0
                            if (tailerReviews.length > 0) {
                                const totalRating = tailerReviews.reduce((sum, review) => sum + (review.rating || 0), 0)
                                rating = totalRating / tailerReviews.length
                            }

                            return {
                                ...tailor,
                                rating,
                                reviewCount: tailerReviews.length,
                            }
                        }),
                    )

                    // Sort by rating
                    tailorsWithRatings.sort((a, b) => b.rating - a.rating)
                    setPopularTailors(tailorsWithRatings)
                }

                // Set all stats
                setStats({
                    totalOrders,
                    pendingOrders,
                    completedOrders,
                    totalRevenue,
                    averageRating,
                    unreadMessages,
                })

                setLoading(false)
            } catch (err) {
                console.error("Error fetching dashboard data:", err)
                setLoading(false)
            }
        }

        fetchDashboardData()
    }, [userData, timeframe])

    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        )
    }

    const getStatusBadgeVariant = (status: string) => {
        switch (status) {
            case "pending":
                return "secondary"
            case "accepted":
                return "default"
            case "in-progress":
                return "default"
            case "completed":
                return "success"
            case "cancelled":
                return "destructive"
            default:
                return "outline"
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
                <Tabs value={timeframe} onValueChange={(value) => setTimeframe(value as "week" | "month" | "year")}>
                    <TabsList>
                        <TabsTrigger value="week">This Week</TabsTrigger>
                        <TabsTrigger value="month">This Month</TabsTrigger>
                        <TabsTrigger value="year">This Year</TabsTrigger>
                    </TabsList>
                </Tabs>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
                                <h3 className="text-2xl font-bold">{stats.totalOrders}</h3>
                            </div>
                            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10">
                                <ShoppingBag className="w-6 h-6 text-primary" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">Pending Orders</p>
                                <h3 className="text-2xl font-bold">{stats.pendingOrders}</h3>
                            </div>
                            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-yellow-500/10">
                                <Clock className="w-6 h-6 text-yellow-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {userData?.role === "tailor" && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Average Rating</p>
                                    <div className="flex items-center">
                                        <h3 className="mr-2 text-2xl font-bold">{stats.averageRating.toFixed(1)}</h3>
                                        <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                                    </div>
                                </div>
                                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-yellow-500/10">
                                    <Star className="w-6 h-6 text-yellow-500" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {(userData?.role === "tailor" || userData?.role === "admin") && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                                    <h3 className="text-2xl font-bold">${stats.totalRevenue.toFixed(2)}</h3>
                                </div>
                                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-500/10">
                                    <TrendingUp className="w-6 h-6 text-green-500" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {userData?.role === "customer" && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Completed Orders</p>
                                    <h3 className="text-2xl font-bold">{stats.completedOrders}</h3>
                                </div>
                                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-500/10">
                                    <ShoppingBag className="w-6 h-6 text-green-500" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">Unread Messages</p>
                                <h3 className="text-2xl font-bold">{stats.unreadMessages}</h3>
                            </div>
                            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-500/10">
                                <MessageSquare className="w-6 h-6 text-blue-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                {/* Recent Orders */}
                <Card className="col-span-1">
                    <CardHeader>
                        <CardTitle>Recent Orders</CardTitle>
                        <CardDescription>Your most recent orders and their status</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {recentOrders.length === 0 ? (
                            <p className="py-6 text-center text-muted-foreground">No orders yet</p>
                        ) : (
                            <div className="space-y-4">
                                {recentOrders.map((order) => (
                                    <Link key={order.id} to={`/orders/${order.id}`} className="block">
                                        <div className="p-4 transition-colors border rounded-lg hover:border-primary">
                                            <div className="flex flex-col justify-between gap-4 sm:flex-row">
                                                <div>
                                                    <h3 className="font-medium">{order.clothingType}</h3>
                                                    <p className="text-sm text-muted-foreground">
                                                        {userData?.role === "customer"
                                                            ? `Tailor: ${order.tailorName}`
                                                            : `Customer: ${order.customerName}`}
                                                    </p>
                                                </div>
                                                <div className="flex flex-col gap-2 sm:items-end">
                                                    <Badge variant={getStatusBadgeVariant(order.status)}>
                                                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                                    </Badge>
                                                    <p className="text-xs text-muted-foreground">{order.createdAt.toLocaleDateString()}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        )}
                    </CardContent>
                    <CardFooter>
                        <Button asChild variant="outline" className="w-full">
                            <Link to="/orders">View All Orders</Link>
                        </Button>
                    </CardFooter>
                </Card>

                {/* Recent Reviews or Popular Tailors */}
                <Card className="col-span-1">
                    {userData?.role === "tailor" ? (
                        <>
                            <CardHeader>
                                <CardTitle>Recent Reviews</CardTitle>
                                <CardDescription>Latest feedback from your customers</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {recentReviews.length === 0 ? (
                                    <p className="py-6 text-center text-muted-foreground">No reviews yet</p>
                                ) : (
                                    <div className="space-y-4">
                                        {recentReviews.map((review) => (
                                            <div key={review.id} className="p-4 border rounded-lg">
                                                <div className="flex items-start gap-4">
                                                    <Avatar className="w-10 h-10">
                                                        <AvatarFallback>{review.customerName.charAt(0).toUpperCase()}</AvatarFallback>
                                                    </Avatar>
                                                    <div className="flex-1">
                                                        <div className="flex items-center justify-between">
                                                            <h4 className="font-medium">{review.customerName}</h4>
                                                            <span className="text-xs text-muted-foreground">
                                                                {review.createdAt.toLocaleDateString()}
                                                            </span>
                                                        </div>
                                                        <div className="flex my-1">
                                                            {[1, 2, 3, 4, 5].map((value) => (
                                                                <Star
                                                                    key={value}
                                                                    className={`h-4 w-4 ${value <= review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                                                        }`}
                                                                />
                                                            ))}
                                                        </div>
                                                        <p className="mt-2 text-muted-foreground line-clamp-2">{review.comment}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                            <CardFooter>
                                <Button asChild variant="outline" className="w-full">
                                    <Link to="/reviews">View All Reviews</Link>
                                </Button>
                            </CardFooter>
                        </>
                    ) : (
                        <>
                            <CardHeader>
                                <CardTitle>Popular Tailors</CardTitle>
                                <CardDescription>Highly rated tailors you might want to try</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {popularTailors.length === 0 ? (
                                    <p className="py-6 text-center text-muted-foreground">No tailors available</p>
                                ) : (
                                    <div className="space-y-4">
                                        {popularTailors.map((tailor) => (
                                            <Link key={tailor.id} to={`/tailors/${tailor.id}`} className="block">
                                                <div className="p-4 transition-colors border rounded-lg hover:border-primary">
                                                    <div className="flex items-center gap-4">
                                                        <Avatar className="w-12 h-12">
                                                            <AvatarImage src={tailor.photoURL || ""} alt={tailor.displayName} />
                                                            <AvatarFallback>{tailor.displayName.charAt(0).toUpperCase()}</AvatarFallback>
                                                        </Avatar>
                                                        <div className="flex-1">
                                                            <h4 className="font-medium">{tailor.displayName}</h4>
                                                            <div className="flex items-center mt-1">
                                                                <div className="flex">
                                                                    {[1, 2, 3, 4, 5].map((value) => (
                                                                        <Star
                                                                            key={value}
                                                                            className={`h-3 w-3 ${value <= Math.round(tailor.rating || 0)
                                                                                    ? "text-yellow-500 fill-yellow-500"
                                                                                    : "text-gray-300"
                                                                                }`}
                                                                        />
                                                                    ))}
                                                                </div>
                                                                <span className="ml-2 text-xs text-muted-foreground">
                                                                    ({tailor.reviewCount || 0} reviews)
                                                                </span>
                                                            </div>
                                                            {tailor.specialties && tailor.specialties.length > 0 && (
                                                                <div className="flex flex-wrap gap-1 mt-2">
                                                                    {tailor.specialties.slice(0, 2).map((specialty, index) => (
                                                                        <Badge key={index} variant="outline" className="text-xs">
                                                                            {specialty}
                                                                        </Badge>
                                                                    ))}
                                                                    {tailor.specialties.length > 2 && (
                                                                        <Badge variant="outline" className="text-xs">
                                                                            +{tailor.specialties.length - 2} more
                                                                        </Badge>
                                                                    )}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </Link>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                            <CardFooter>
                                <Button asChild variant="outline" className="w-full">
                                    <Link to="/tailors">View All Tailors</Link>
                                </Button>
                            </CardFooter>
                        </>
                    )}
                </Card>
            </div>
        </div>
    )
}
