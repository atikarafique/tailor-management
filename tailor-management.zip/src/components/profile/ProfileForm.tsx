"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { useAuth } from "../../contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Loader2, Upload } from "lucide-react"
import { storage } from "../../lib/firebase"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"

export default function ProfileForm() {
  const { userData, updateUserProfile } = useAuth()
  const [displayName, setDisplayName] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [address, setAddress] = useState("")
  const [bio, setBio] = useState("")
  const [specialties, setSpecialties] = useState("")
  const [photoURL, setPhotoURL] = useState("")
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (userData) {
      setDisplayName(userData.displayName || "")
      setPhoneNumber(userData.phoneNumber || "")
      setAddress(userData.address || "")
      setBio(userData.bio || "")
      setPhotoURL(userData.photoURL || "")
      setSpecialties(userData.specialties?.join(", ") || "")
    }
  }, [userData])

  async function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) {
      setPhotoFile(file)
      // Create a preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setPhotoURL(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    try {
      setError("")
      setSuccess("")
      setLoading(true)

      let updatedPhotoURL = userData?.photoURL

      // Upload photo if changed
      if (photoFile) {
        const storageRef = ref(storage, `profile-photos/${userData?.id}`)
        await uploadBytes(storageRef, photoFile)
        updatedPhotoURL = await getDownloadURL(storageRef)
      }

      const specialtiesArray = specialties
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s.length > 0)

      await updateUserProfile({
        displayName,
        phoneNumber,
        address,
        bio,
        photoURL: updatedPhotoURL,
        specialties: specialtiesArray,
      })

      setSuccess("Profile updated successfully")
    } catch (err) {
      setError("Failed to update profile")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="text-2xl">Profile Settings</CardTitle>
        <CardDescription>Update your personal information and profile settings</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {success && (
          <Alert className="mb-4">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <Avatar className="h-24 w-24">
              <AvatarImage src={photoURL || "/placeholder.svg"} alt={displayName} />
              <AvatarFallback>{displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex items-center">
              <Label htmlFor="photo" className="cursor-pointer">
                <div className="flex items-center space-x-2 text-primary">
                  <Upload size={16} />
                  <span>Change photo</span>
                </div>
                <Input id="photo" type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
              </Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Full Name</Label>
            <Input id="name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input id="phone" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea id="bio" value={bio} onChange={(e) => setBio(e.target.value)} rows={4} />
          </div>

          {userData?.role === "tailor" && (
            <div className="space-y-2">
              <Label htmlFor="specialties">Specialties (comma separated)</Label>
              <Input
                id="specialties"
                value={specialties}
                onChange={(e) => setSpecialties(e.target.value)}
                placeholder="e.g. Shalwar Kameez, Formal Suits, Wedding Dresses"
              />
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving changes...
              </>
            ) : (
              "Save changes"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
