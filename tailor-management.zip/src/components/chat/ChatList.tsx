"use client"
import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Loader2, Search } from "lucide-react"
import { rdb } from "../../lib/firebase"
import { ref, onValue } from "firebase/database"
import type { Chat } from "../../types"

export default function ChatList() {
  const { userData } = useAuth()
  const [chats, setChats] = useState<Chat[]>([])
  const [filteredChats, setFilteredChats] = useState<Chat[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    if (!userData) return

    // Reference to the chats node in Realtime Database
    const chatsRef = ref(rdb, "chats")

    // Listen for changes to chats
    const unsubscribe = onValue(
      chatsRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const chatsData: Chat[] = []
          snapshot.forEach((childSnapshot) => {
            const chat = childSnapshot.val()
            // Only include chats where the current user is a participant
            if (chat.participants && chat.participants.includes(userData.id)) {
              chatsData.push({
                id: childSnapshot.key || "",
                ...chat,
                lastMessageTime: chat.lastMessageTime ? new Date(chat.lastMessageTime) : new Date(),
              })
            }
          })

          // Sort chats by last message time (newest first)
          chatsData.sort((a, b) => b.lastMessageTime.getTime() - a.lastMessageTime.getTime())

          setChats(chatsData)
          setFilteredChats(chatsData)
        }
        setLoading(false)
      },
      (error) => {
        console.error("Error fetching chats:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [userData])

  useEffect(() => {
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      const filtered = chats.filter((chat) => {
        const otherParticipantId = chat.participants.find((id) => id !== userData?.id)
        const otherParticipantName = otherParticipantId ? chat.participantNames[otherParticipantId] : ""
        return otherParticipantName.toLowerCase().includes(term)
      })
      setFilteredChats(filtered)
    } else {
      setFilteredChats(chats)
    }
  }, [searchTerm, chats, userData?.id])

  const getOtherParticipantInfo = (chat: Chat) => {
    const otherParticipantId = chat.participants.find((id) => id !== userData?.id)
    if (!otherParticipantId) return { name: "Unknown", initial: "U" }

    const name = chat.participantNames[otherParticipantId] || "Unknown"
    const initial = name.charAt(0).toUpperCase()

    return { name, initial }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">Messages</CardTitle>
        <CardDescription>Chat with tailors and customers</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {filteredChats.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-muted-foreground">No conversations yet</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredChats.map((chat) => {
                const { name, initial } = getOtherParticipantInfo(chat)
                const unreadCount = chat.unreadCount && userData?.id ? chat.unreadCount[userData.id] || 0 : 0

                return (
                  <Link key={chat.id} to={`/chat/${chat.id}`} className="block">
                    <div className="flex items-center p-3 transition-colors rounded-lg hover:bg-accent">
                      <Avatar className="w-10 h-10 mr-3">
                        <AvatarImage src="/placeholder.svg" alt={name} />
                        <AvatarFallback>{initial}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium truncate">{name}</h4>
                          <span className="text-xs text-muted-foreground">
                            {chat.lastMessageTime.toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-sm truncate text-muted-foreground">
                          {chat.lastMessage || "No messages yet"}
                        </p>
                      </div>
                      {unreadCount > 0 && <Badge className="ml-2">{unreadCount}</Badge>}
                    </div>
                  </Link>
                )
              })}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
