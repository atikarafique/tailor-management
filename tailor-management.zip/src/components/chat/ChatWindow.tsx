"use client"
import { useState, useEffect, useRef } from "react"
import type React from "react"

import { useParams, useNavigate } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Loader2, ArrowLeft, Send } from "lucide-react"
import { db, rdb } from "../../lib/firebase"
import { doc, getDoc } from "firebase/firestore"
import { ref, onValue, push, set, update, get, child, serverTimestamp as rtdbServerTimestamp } from "firebase/database"
import type { Chat, Message, User } from "../../types"

export default function ChatWindow() {
  const { id } = useParams<{ id: string }>()
  const { userData } = useAuth()
  const navigate = useNavigate()
  const [chat, setChat] = useState<Chat | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [otherUser, setOtherUser] = useState<User | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    async function initializeChat() {
      if (!userData || !id) return

      try {
        // Check if this is a new chat (format: userId1_userId2)
        if (id.includes("_")) {
          const [user1Id, user2Id] = id.split("_")
          const participants = [user1Id, user2Id]

          // Make sure the current user is one of the participants
          if (!participants.includes(userData.id)) {
            navigate("/chat")
            return
          }

          // Get the other user's info
          const otherUserId = participants.find((uid) => uid !== userData.id)
          if (!otherUserId) {
            navigate("/chat")
            return
          }

          const otherUserDoc = await getDoc(doc(db, "users", otherUserId))
          if (!otherUserDoc.exists()) {
            navigate("/chat")
            return
          }

          const otherUserData = otherUserDoc.data() as User
          setOtherUser(otherUserData)

          // Check if a chat already exists between these users
          const chatsRef = ref(rdb, "chats")
          const chatsSnapshot = await get(chatsRef)

          let existingChatId = null

          if (chatsSnapshot.exists()) {
            chatsSnapshot.forEach((chatSnapshot) => {
              const chatData = chatSnapshot.val()
              if (
                chatData.participants &&
                chatData.participants.includes(userData.id) &&
                chatData.participants.includes(otherUserId)
              ) {
                existingChatId = chatSnapshot.key
              }
            })
          }

          if (existingChatId) {
            // Redirect to the existing chat
            navigate(`/chat/${existingChatId}`, { replace: true })
          } else {
            // Create a new chat
            createNewChat(userData, otherUserData)
          }
        } else {
          // Existing chat
          const chatRef = ref(rdb, `chats/${id}`)

          // Get chat data
          const chatSnapshot = await get(chatRef)

          if (!chatSnapshot.exists()) {
            navigate("/chat")
            return
          }

          const chatData = {
            id: chatSnapshot.key || id,
            ...chatSnapshot.val(),
            lastMessageTime: chatSnapshot.val().lastMessageTime
              ? new Date(chatSnapshot.val().lastMessageTime)
              : new Date(),
          } as Chat

          // Make sure the current user is a participant
          if (!chatData.participants.includes(userData.id)) {
            navigate("/chat")
            return
          }

          setChat(chatData)

          // Get the other user's info
          const otherUserId = chatData.participants.find((uid) => uid !== userData.id)
          if (otherUserId) {
            const otherUserDoc = await getDoc(doc(db, "users", otherUserId))
            if (otherUserDoc.exists()) {
              setOtherUser(otherUserDoc.data() as User)
            }
          }

          // Mark messages as read
          update(ref(rdb, `chats/${id}/unreadCount`), {
            [userData.id]: 0,
          })

          // Listen for messages
          const messagesRef = ref(rdb, `messages/${id}`)

          const unsubscribe = onValue(messagesRef, (snapshot) => {
            if (snapshot.exists()) {
              const messagesData: Message[] = []
              snapshot.forEach((childSnapshot) => {
                const message = childSnapshot.val()
                messagesData.push({
                  id: childSnapshot.key || "",
                  ...message,
                  createdAt: message.createdAt ? new Date(message.createdAt) : new Date(),
                })
              })

              // Sort messages by creation time
              messagesData.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())

              setMessages(messagesData)

              // Mark messages as read
              messagesData.forEach((message) => {
                if (message.senderId !== userData.id && !message.read) {
                  update(child(messagesRef, message.id), {
                    read: true,
                  })
                }
              })
            }

            setLoading(false)
          })

          return () => unsubscribe()
        }
      } catch (err) {
        console.error("Error initializing chat:", err)
        setLoading(false)
        navigate("/chat")
      }
    }

    async function createNewChat(currentUser: User, otherUser: User) {
      try {
        const participantNames: Record<string, string> = {
          [currentUser.id]: currentUser.displayName,
          [otherUser.id]: otherUser.displayName,
        }

        // Create a new chat in Realtime Database
        const chatsRef = ref(rdb, "chats")
        const newChatRef = push(chatsRef)

        await set(newChatRef, {
          participants: [currentUser.id, otherUser.id],
          participantNames,
          createdAt: rtdbServerTimestamp(),
        })

        // Set unread counts separately
        await set(ref(rdb, `chats/${newChatRef.key}/unreadCount`), {
          [currentUser.id]: 0,
          [otherUser.id]: 0,
        })

        navigate(`/chat/${newChatRef.key}`, { replace: true })
      } catch (err) {
        console.error("Error creating new chat:", err)
      }
    }

    initializeChat()
  }, [userData, id, navigate])

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userData || !chat || !newMessage.trim()) return

    try {
      setSending(true)

      const otherUserId = chat.participants.find((uid) => uid !== userData.id)
      if (!otherUserId) return

      // Add message to Realtime Database
      const messagesRef = ref(rdb, `messages/${chat.id}`)
      const newMessageRef = push(messagesRef)

      await set(newMessageRef, {
        chatId: chat.id,
        senderId: userData.id,
        senderName: userData.displayName,
        content: newMessage,
        createdAt: rtdbServerTimestamp(),
        read: false,
      })

      // Update chat in Realtime Database
      await update(ref(rdb, `chats/${chat.id}`), {
        lastMessage: newMessage,
        lastMessageTime: rtdbServerTimestamp(),
      })

      // Update unread count separately
      await update(ref(rdb, `chats/${chat.id}/unreadCount`), {
        [otherUserId]: (chat.unreadCount?.[otherUserId] || 0) + 1,
      })

      setNewMessage("")
      setSending(false)
    } catch (err) {
      console.error("Error sending message:", err)
      setSending(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card className="w-full h-[calc(100vh-12rem)]">
      <CardHeader className="p-4 border-b">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" asChild className="mr-2">
            <div onClick={() => navigate("/chat")}>
              <ArrowLeft className="w-4 h-4" />
            </div>
          </Button>
          {otherUser && (
            <div className="flex items-center">
              <Avatar className="w-8 h-8 mr-2">
                <AvatarImage src={otherUser.photoURL || ""} alt={otherUser.displayName} />
                <AvatarFallback>{otherUser.displayName.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium">{otherUser.displayName}</h3>
                <p className="text-xs text-muted-foreground">{otherUser.role}</p>
              </div>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0 flex flex-col h-[calc(100%-8rem)]">
        <div className="flex-1 p-4 overflow-y-auto">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => {
                const isCurrentUser = message.senderId === userData?.id

                return (
                  <div key={message.id} className={`flex ${isCurrentUser ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[70%] rounded-lg px-4 py-2 ${isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                    >
                      <p>{message.content}</p>
                      <p className="mt-1 text-xs opacity-70">
                        {message.createdAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
        <div className="p-4 border-t">
          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1"
            />
            <Button type="submit" size="icon" disabled={sending || !newMessage.trim()}>
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}
