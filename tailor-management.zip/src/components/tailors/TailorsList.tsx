"use client"
import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Loader2, Search, Star } from "lucide-react"
import { db } from "../../lib/firebase"
import { collection, query, where, getDocs } from "firebase/firestore"
import type { User } from "../../types"

export default function TailorsList() {
    const { userData } = useAuth()
    const [tailors, setTailors] = useState<User[]>([])
    const [filteredTailors, setFilteredTailors] = useState<User[]>([])
    const [loading, setLoading] = useState(true)
    const [searchTerm, setSearchTerm] = useState("")
    const [tailorRatings, setTailorRatings] = useState<Record<string, { count: number; average: number }>>({})

    useEffect(() => {
        async function fetchTailors() {
            try {
                const tailorsQuery = query(collection(db, "users"), where("role", "==", "tailor"))
                const tailorsSnapshot = await getDocs(tailorsQuery)
                const tailorsData = tailorsSnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                    createdAt: doc.data().createdAt?.toDate() || new Date(),
                })) as User[]

                setTailors(tailorsData)
                setFilteredTailors(tailorsData)
                setLoading(false)

                // Fetch ratings for each tailor
                const ratingsData: Record<string, { count: number; average: number }> = {}

                for (const tailor of tailorsData) {
                    const reviewsQuery = query(collection(db, "reviews"), where("tailorId", "==", tailor.id))
                    const reviewsSnapshot = await getDocs(reviewsQuery)

                    if (!reviewsSnapshot.empty) {
                        const reviews = reviewsSnapshot.docs.map((doc) => doc.data())
                        const totalRating = reviews.reduce((sum, review) => sum + (review.rating || 0), 0)
                        ratingsData[tailor.id] = {
                            count: reviews.length,
                            average: totalRating / reviews.length,
                        }
                    } else {
                        ratingsData[tailor.id] = {
                            count: 0,
                            average: 0,
                        }
                    }
                }

                setTailorRatings(ratingsData)
            } catch (err) {
                console.error("Error fetching tailors:", err)
                setLoading(false)
            }
        }

        fetchTailors()
    }, [])

    useEffect(() => {
        if (searchTerm) {
            const term = searchTerm.toLowerCase()
            const filtered = tailors.filter(
                (tailor) =>
                    tailor.displayName.toLowerCase().includes(term) ||
                    (tailor.specialties && tailor.specialties.some((specialty) => specialty.toLowerCase().includes(term))),
            )
            setFilteredTailors(filtered)
        } else {
            setFilteredTailors(tailors)
        }
    }, [searchTerm, tailors])

    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        )
    }

    return (
        <Card className="w-full">
            <CardHeader>
                <CardTitle className="text-2xl">Find a Tailor</CardTitle>
                <CardDescription>Browse our skilled tailors and find the perfect match for your clothing needs</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-6">
                    <div className="relative">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                            placeholder="Search by name or specialty..."
                            className="pl-8"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    {filteredTailors.length === 0 ? (
                        <div className="py-12 text-center">
                            <p className="text-muted-foreground">No tailors found</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                            {filteredTailors.map((tailor) => (
                                <Link key={tailor.id} to={`/tailors/${tailor.id}`} className="block">
                                    <Card className="h-full transition-shadow hover:shadow-md">
                                        <CardContent className="p-6">
                                            <div className="flex flex-col items-center text-center">
                                                <Avatar className="w-24 h-24 mb-4">
                                                    <AvatarImage src={tailor.photoURL || ""} alt={tailor.displayName} />
                                                    <AvatarFallback>{tailor.displayName.charAt(0).toUpperCase()}</AvatarFallback>
                                                </Avatar>
                                                <h3 className="mb-1 text-lg font-semibold">{tailor.displayName}</h3>

                                                {tailorRatings[tailor.id] && (
                                                    <div className="flex items-center mb-2">
                                                        <div className="flex">
                                                            {[1, 2, 3, 4, 5].map((value) => (
                                                                <Star
                                                                    key={value}
                                                                    className={`h-4 w-4 ${value <= Math.round(tailorRatings[tailor.id].average)
                                                                            ? "text-yellow-500 fill-yellow-500"
                                                                            : "text-gray-300"
                                                                        }`}
                                                                />
                                                            ))}
                                                        </div>
                                                        <span className="ml-2 text-sm text-muted-foreground">
                                                            ({tailorRatings[tailor.id].count})
                                                        </span>
                                                    </div>
                                                )}

                                                {tailor.bio && <p className="mb-4 text-sm text-muted-foreground line-clamp-2">{tailor.bio}</p>}

                                                {tailor.specialties && tailor.specialties.length > 0 && (
                                                    <div className="flex flex-wrap justify-center gap-2">
                                                        {tailor.specialties.slice(0, 3).map((specialty, index) => (
                                                            <Badge key={index} variant="secondary">
                                                                {specialty}
                                                            </Badge>
                                                        ))}
                                                        {tailor.specialties.length > 3 && (
                                                            <Badge variant="outline">+{tailor.specialties.length - 3} more</Badge>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        </CardContent>
                                    </Card>
                                </Link>
                            ))}
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    )
}
