"use client"
import { useState, useEffect } from "react"
import { useParams, Link } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Loader2, ArrowLeft, MessageSquare, ShoppingBag } from "lucide-react"
import { db } from "../../lib/firebase"
import { doc, getDoc, collection, query, where, getDocs, orderBy } from "firebase/firestore"
import type { User, Order } from "../../types"
import ReviewList from "../reviews/ReviewList"

export default function TailorProfile() {
    const { id } = useParams<{ id: string }>()
    const { userData } = useAuth()
    const [tailor, setTailor] = useState<User | null>(null)
    const [orders, setOrders] = useState<Order[]>([])
    const [loading, setLoading] = useState(true)
    const [activeTab, setActiveTab] = useState("about")

    useEffect(() => {
        async function fetchTailorData() {
            if (!id) return

            try {
                const tailorDoc = await getDoc(doc(db, "users", id))

                if (!tailorDoc.exists()) {
                    setLoading(false)
                    return
                }

                const tailorData = {
                    id: tailorDoc.id,
                    ...tailorDoc.data(),
                    createdAt: tailorDoc.data().createdAt?.toDate() || new Date(),
                } as User

                setTailor(tailorData)

                // If the current user is a customer, fetch their orders with this tailor
                if (userData?.role === "customer") {
                    const ordersQuery = query(
                        collection(db, "orders"),
                        where("customerId", "==", userData.id),
                        where("tailorId", "==", id),
                        orderBy("createdAt", "desc"),
                    )

                    const ordersSnapshot = await getDocs(ordersQuery)
                    const ordersData = ordersSnapshot.docs.map((doc) => ({
                        id: doc.id,
                        ...doc.data(),
                        createdAt: doc.data().createdAt?.toDate() || new Date(),
                        updatedAt: doc.data().updatedAt?.toDate() || new Date(),
                    })) as Order[]

                    setOrders(ordersData)
                }

                setLoading(false)
            } catch (err) {
                console.error("Error fetching tailor data:", err)
                setLoading(false)
            }
        }

        fetchTailorData()
    }, [id, userData])

    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        )
    }

    if (!tailor) {
        return (
            <div className="py-12 text-center">
                <p className="text-muted-foreground">Tailor not found</p>
                <Button asChild variant="outline" className="mt-4">
                    <Link to="/tailors">Back to Tailors</Link>
                </Button>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <Button variant="ghost" size="sm" asChild className="mb-4">
                <Link to="/tailors">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Tailors
                </Link>
            </Button>

            <Card>
                <CardContent className="p-6">
                    <div className="flex flex-col items-center gap-6 md:flex-row md:items-start">
                        <Avatar className="w-32 h-32">
                            <AvatarImage src={tailor.photoURL || ""} alt={tailor.displayName} />
                            <AvatarFallback className="text-4xl">{tailor.displayName.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 text-center md:text-left">
                            <h1 className="text-3xl font-bold">{tailor.displayName}</h1>
                            <p className="text-muted-foreground">Tailor</p>

                            {tailor.specialties && tailor.specialties.length > 0 && (
                                <div className="flex flex-wrap justify-center gap-2 mt-3 md:justify-start">
                                    {tailor.specialties.map((specialty, index) => (
                                        <Badge key={index} variant="secondary">
                                            {specialty}
                                        </Badge>
                                    ))}
                                </div>
                            )}

                            <div className="flex flex-col justify-center gap-3 mt-6 sm:flex-row md:justify-start">
                                {userData?.role === "customer" && (
                                    <>
                                        <Button asChild>
                                            <Link to={`/orders/new?tailorId=${tailor.id}`}>
                                                <ShoppingBag className="w-4 h-4 mr-2" />
                                                Place Order
                                            </Link>
                                        </Button>
                                        <Button asChild variant="outline">
                                            <Link to={`/chat/${userData.id}_${tailor.id}`}>
                                                <MessageSquare className="w-4 h-4 mr-2" />
                                                Message
                                            </Link>
                                        </Button>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="about">About</TabsTrigger>
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>
                <TabsContent value="about" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>About {tailor.displayName}</CardTitle>
                            <CardDescription>Learn more about this tailor's experience and services</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {tailor.bio ? (
                                <div>
                                    <h3 className="mb-2 text-lg font-medium">Bio</h3>
                                    <p className="text-muted-foreground">{tailor.bio}</p>
                                </div>
                            ) : (
                                <p className="text-muted-foreground">No bio provided</p>
                            )}

                            <Separator />

                            <div>
                                <h3 className="mb-2 text-lg font-medium">Contact Information</h3>
                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-muted-foreground">Email:</span>
                                        <span>{tailor.email}</span>
                                    </div>
                                    {tailor.phoneNumber && (
                                        <div className="flex justify-between">
                                            <span className="text-muted-foreground">Phone:</span>
                                            <span>{tailor.phoneNumber}</span>
                                        </div>
                                    )}
                                    {tailor.address && (
                                        <div className="flex justify-between">
                                            <span className="text-muted-foreground">Address:</span>
                                            <span>{tailor.address}</span>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {userData?.role === "customer" && orders.length > 0 && (
                                <>
                                    <Separator />
                                    <div>
                                        <h3 className="mb-2 text-lg font-medium">Your Orders with {tailor.displayName}</h3>
                                        <div className="space-y-3">
                                            {orders.map((order) => (
                                                <Link key={order.id} to={`/orders/${order.id}`} className="block">
                                                    <div className="p-3 transition-colors border rounded-lg hover:border-primary">
                                                        <div className="flex justify-between">
                                                            <div>
                                                                <h4 className="font-medium">{order.clothingType}</h4>
                                                                <p className="text-xs text-muted-foreground">
                                                                    Ordered on {order.createdAt.toLocaleDateString()}
                                                                </p>
                                                            </div>
                                                            <Badge
                                                                variant={
                                                                    order.status === "completed"
                                                                        ? "success"
                                                                        : order.status === "cancelled"
                                                                            ? "destructive"
                                                                            : "secondary"
                                                                }
                                                            >
                                                                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                                            </Badge>
                                                        </div>
                                                    </div>
                                                </Link>
                                            ))}
                                        </div>
                                    </div>
                                </>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="reviews" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Customer Reviews</CardTitle>
                            <CardDescription>See what customers are saying about {tailor.displayName}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <ReviewList tailorId={tailor.id} />
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    )
}
