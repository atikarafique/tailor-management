import { defineAbility } from "@casl/ability"
import type { User } from "../types"

export type Actions = "create" | "read" | "update" | "delete" | "manage"
export type Subjects = "Order" | "Profile" | "Review" | "Chat" | "all"

export const defineAbilityFor = (user: User | null) => {
  return defineAbility((can, cannot) => {
    if (!user) return

    if (user.role === "admin") {
      can("manage", "all")
    }

    if (user.role === "tailor") {
      can(["read", "update"], "Order")
      can(["read", "create"], "Chat")
      can("read", "Review")
      can(["read", "update"], "Profile", { id: user.id })
    }

    if (user.role === "customer") {
      can(["create", "read", "update", "delete"], "Order", { customerId: user.id })
      can(["read", "create"], "Chat")
      can(["create", "read"], "Review")
      can(["read", "update"], "Profile", { id: user.id })
    }
  })
}
