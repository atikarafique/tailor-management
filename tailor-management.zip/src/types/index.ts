export interface User {
  id: string
  email: string
  displayName: string
  role: "customer" | "tailor" | "admin"
  photoURL?: string
  phoneNumber?: string
  address?: string
  bio?: string
  specialties?: string[]
  createdAt: Date
}

export interface Order {
  id: string
  customerId: string
  customerName: string
  tailorId: string
  tailorName: string
  clothingType: string
  measurements: Measurements
  status: "pending" | "accepted" | "in-progress" | "completed" | "cancelled"
  price: number
  notes?: string
  createdAt: Date
  updatedAt: Date
}

export interface Measurements {
  neck?: number
  chest?: number
  waist?: number
  hips?: number
  shoulder?: number
  armLength?: number
  inseam?: number
  height?: number
  kameezLength?: number
  shalwarLength?: number
  shalwarWaist?: number
  customMeasurements?: Record<string, number>
}

export interface Review {
  id: string
  orderId: string
  customerId: string
  customerName: string
  tailorId: string
  rating: number
  comment: string
  createdAt: Date
}

export interface Message {
  id: string
  chatId: string
  senderId: string
  senderName: string
  content: string
  createdAt: Date
  read: boolean
}

export interface Chat {
  id: string
  participants: string[]
  participantNames: Record<string, string>
  lastMessage?: string
  lastMessageTime?: Date
  unreadCount: Record<string, number>
}

export interface ClothingType {
  id: string
  name: string
  category: string
  description: string
  imageUrl: string
  requiredMeasurements: string[]
}
