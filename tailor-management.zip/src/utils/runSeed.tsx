"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { seedClothingTypes } from "../scripts/seedClothingTypes"

export default function RunSeed() {
    const [loading, setLoading] = useState(false)
    const [message, setMessage] = useState("")
    const [error, setError] = useState("")

    const handleSeed = async () => {
        try {
            setLoading(true)
            setMessage("")
            setError("")

            await seedClothingTypes()

            setMessage("Successfully seeded clothing types!")
        } catch (err) {
            console.error("Error running seed:", err)
            setError("Failed to seed data. Check console for details.")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="space-y-4">
            {message && (
                <Alert>
                    <AlertDescription>{message}</AlertDescription>
                </Alert>
            )}

            {error && (
                <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            <Button onClick={handleSeed} disabled={loading}>
                {loading ? "Seeding..." : "Seed Clothing Types"}
            </Button>
        </div>
    )
}
