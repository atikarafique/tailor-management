"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  updateProfile,
  type User as FirebaseUser,
} from "firebase/auth"
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore"
import { auth, db } from "../lib/firebase"
import type { User } from "../types"

interface AuthContextType {
  currentUser: FirebaseUser | null
  userData: User | null
  loading: boolean
  signup: (email: string, password: string, displayName: string, role: "customer" | "tailor") => Promise<void>
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
  updateUserProfile: (data: Partial<User>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// LocalStorage keys
const LOCAL_STORAGE_USER_KEY = "currentUser"
const LOCAL_STORAGE_USER_DATA_KEY = "userData"

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Initialize state with localStorage values if they exist
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem(LOCAL_STORAGE_USER_KEY)
      return storedUser ? JSON.parse(storedUser) : null
    }
    return null
  })

  const [userData, setUserData] = useState<User | null>(() => {
    if (typeof window !== "undefined") {
      const storedData = localStorage.getItem(LOCAL_STORAGE_USER_DATA_KEY)
      return storedData ? JSON.parse(storedData) : null
    }
    return null
  })

  const [loading, setLoading] = useState(true)

  async function signup(email: string, password: string, displayName: string, role: "customer" | "tailor") {
    try {
      setLoading(true)
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      await updateProfile(userCredential.user, { displayName })

      const userData: User = {
        id: userCredential.user.uid,
        email,
        displayName,
        role,
        createdAt: new Date(),
      }

      await setDoc(doc(db, "users", userCredential.user.uid), {
        ...userData,
        createdAt: serverTimestamp(),
      })

      // Update state and localStorage
      setCurrentUser(userCredential.user)
      setUserData(userData)

      if (typeof window !== "undefined") {
        localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(userCredential.user))
        localStorage.setItem(LOCAL_STORAGE_USER_DATA_KEY, JSON.stringify(userData))
      }
    } catch (error) {
      console.error("Signup error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  async function login(email: string, password: string) {
    try {
      setLoading(true)
      const userCredential = await signInWithEmailAndPassword(auth, email, password)

      // Fetch user profile data from Firestore
      const userDoc = await getDoc(doc(db, "users", userCredential.user.uid))
      if (!userDoc.exists()) {
        throw new Error("User document not found")
      }

      const userData = userDoc.data() as User

      // Update state and localStorage
      setCurrentUser(userCredential.user)
      setUserData(userData)

      if (typeof window !== "undefined") {
        localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(userCredential.user))
        localStorage.setItem(LOCAL_STORAGE_USER_DATA_KEY, JSON.stringify(userData))
      }
    } catch (error) {
      console.error("Login error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  async function logout() {
    try {
      setLoading(true)
      await signOut(auth)

      // Clear state and localStorage
      setCurrentUser(null)
      setUserData(null)

      if (typeof window !== "undefined") {
        localStorage.removeItem(LOCAL_STORAGE_USER_KEY)
        localStorage.removeItem(LOCAL_STORAGE_USER_DATA_KEY)
      }
    } catch (error) {
      console.error("Logout error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  async function resetPassword(email: string) {
    try {
      setLoading(true)
      await sendPasswordResetEmail(auth, email)
    } catch (error) {
      console.error("Password reset error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  async function updateUserProfile(data: Partial<User>) {
    if (!currentUser) return

    try {
      setLoading(true)
      const userRef = doc(db, "users", currentUser.uid)
      await setDoc(userRef, data, { merge: true })

      // Update Firebase auth profile if displayName or photoURL changed
      const updates: { displayName?: string; photoURL?: string } = {}
      if (data.displayName) updates.displayName = data.displayName
      if (data.photoURL) updates.photoURL = data.photoURL

      if (Object.keys(updates).length > 0) {
        await updateProfile(currentUser, updates)
      }

      // Update local state and localStorage
      const updatedUserData = userData ? { ...userData, ...data } : null
      setUserData(updatedUserData)

      if (typeof window !== "undefined" && updatedUserData) {
        localStorage.setItem(LOCAL_STORAGE_USER_DATA_KEY, JSON.stringify(updatedUserData))
      }
    } catch (error) {
      console.error("Profile update error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // User is signed in
        setCurrentUser(user)

        try {
          // Fetch user profile data from Firestore
          const userDoc = await getDoc(doc(db, "users", user.uid))
          if (userDoc.exists()) {
            const userData = userDoc.data() as User
            setUserData(userData)

            // Update localStorage
            if (typeof window !== "undefined") {
              localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(user))
              localStorage.setItem(LOCAL_STORAGE_USER_DATA_KEY, JSON.stringify(userData))
            }
          } else {
            // Handle case where user document doesn't exist
            console.warn("User document not found in Firestore")
            setUserData(null)
            if (typeof window !== "undefined") {
              localStorage.removeItem(LOCAL_STORAGE_USER_DATA_KEY)
            }
          }
        } catch (error) {
          console.error("Error fetching user data:", error)
          setUserData(null)
        }
      } else {
        // User is signed out
        setCurrentUser(null)
        setUserData(null)

        // Clear localStorage
        if (typeof window !== "undefined") {
          localStorage.removeItem(LOCAL_STORAGE_USER_KEY)
          localStorage.removeItem(LOCAL_STORAGE_USER_DATA_KEY)
        }
      }

      setLoading(false)
    })

    return unsubscribe
  }, [])

  const value = {
    currentUser,
    userData,
    loading,
    signup,
    login,
    logout,
    resetPassword,
    updateUserProfile,
  }

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>
}