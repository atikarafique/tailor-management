"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import type { Ability } from "@casl/ability"
import { defineAbilityFor } from "../lib/ability"
import { useAuth } from "./AuthContext"

const AbilityContext = createContext<Ability | undefined>(undefined)

export function useAbility() {
  const context = useContext(AbilityContext)
  if (context === undefined) {
    throw new Error("useAbility must be used within an AbilityProvider")
  }
  return context
}

export function AbilityProvider({ children }: { children: React.ReactNode }) {
  const { userData } = useAuth()
  const [ability, setAbility] = useState(() => defineAbilityFor(userData))

  useEffect(() => {
    setAbility(defineAbilityFor(userData))
  }, [userData])

  return <AbilityContext.Provider value={ability}>{children}</AbilityContext.Provider>
}
