"use client"

import { useState } from "react"
import { Link, Outlet, useLocation } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Home, ShoppingBag, MessageSquare, User, LogOut, Menu, X, Users, Star, Settings } from "lucide-react"

export default function Dashboard() {
  const { userData, logout } = useAuth()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: Home },
    { name: "Orders", href: "/orders", icon: ShoppingBag },
    { name: "Messages", href: "/chat", icon: MessageSquare },
    { name: "Profile", href: "/profile", icon: User },
  ]

  if (userData?.role === "customer") {
    navigation.push({ name: "Tailors", href: "/tailors", icon: Users })
  }

  if (userData?.role === "tailor") {
    navigation.push({ name: "Reviews", href: "/reviews", icon: Star })
  }

  if (userData?.role === "admin") {
    navigation.push({ name: "Admin", href: "/admin", icon: Settings })
  }

  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`)
  }

  const handleLogout = async () => {
    try {
      await logout()
    } catch (error) {
      console.error("Failed to log out", error)
    }
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar for desktop */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-1 min-h-0 border-r">
          <div className="flex items-center flex-shrink-0 h-16 px-4 border-b">
            <h1 className="text-xl font-bold text-primary">TailorConnect</h1>
          </div>
          <div className="flex flex-col flex-1 pt-5 pb-4 overflow-y-auto">
            <nav className="flex-1 px-2 mt-5 space-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive(item.href) ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-accent"
                    }`}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex flex-shrink-0 p-4 border-t">
            <div className="flex items-center">
              <Avatar className="w-8 h-8">
                <AvatarImage src={userData?.photoURL || ""} alt={userData?.displayName || ""} />
                <AvatarFallback>{userData?.displayName?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium">{userData?.displayName}</p>
                <p className="text-xs capitalize text-muted-foreground">{userData?.role}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="ml-auto" onClick={handleLogout}>
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className="md:hidden">
        <div className="fixed inset-0 z-40 flex">
          <div
            className={`fixed inset-0 bg-background/80 backdrop-blur-sm transition-opacity ${sidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none"
              }`}
            onClick={() => setSidebarOpen(false)}
          />

          <div
            className={`relative flex-1 flex flex-col max-w-xs w-full bg-background border-r transition-transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full"
              }`}
          >
            <div className="absolute top-0 right-0 pt-2 -mr-12">
              <button
                type="button"
                className="flex items-center justify-center w-10 h-10 ml-1 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
                onClick={() => setSidebarOpen(false)}
              >
                <span className="sr-only">Close sidebar</span>
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
              <div className="flex items-center flex-shrink-0 px-4">
                <h1 className="text-xl font-bold text-primary">TailorConnect</h1>
              </div>
              <nav className="px-2 mt-5 space-y-1">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`group flex items-center px-2 py-2 text-base font-medium rounded-md ${isActive(item.href) ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-accent"
                      }`}
                    onClick={() => setSidebarOpen(false)}
                  >
                    <item.icon className="w-6 h-6 mr-4" />
                    {item.name}
                  </Link>
                ))}
              </nav>
            </div>
            <div className="flex flex-shrink-0 p-4 border-t">
              <div className="flex items-center">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={userData?.photoURL || ""} alt={userData?.displayName || ""} />
                  <AvatarFallback>{userData?.displayName?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
                <div className="ml-3">
                  <p className="text-base font-medium">{userData?.displayName}</p>
                  <p className="text-sm capitalize text-muted-foreground">{userData?.role}</p>
                </div>
                <Button variant="ghost" size="icon" className="ml-auto" onClick={handleLogout}>
                  <LogOut className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 md:pl-64">
        <div className="sticky top-0 z-10 pt-1 pl-1 border-b md:hidden sm:pl-3 sm:pt-3 bg-background">
          <button
            type="button"
            className="-ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-foreground hover:text-primary focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
            onClick={() => setSidebarOpen(true)}
          >
            <span className="sr-only">Open sidebar</span>
            <Menu className="w-6 h-6" />
          </button>
        </div>
        <main className="flex-1">
          <div className="py-6">
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
