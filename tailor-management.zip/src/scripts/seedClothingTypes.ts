import { db } from "../lib/firebase"
import { collection, addDoc, getDocs, query } from "firebase/firestore"
import { clothingTypes } from "../data/clothingTypes"

export async function seedClothingTypes() {
    try {
        // Check if clothing types already exist
        const clothingTypesCollection = collection(db, "clothingTypes")
        const existingTypesQuery = query(clothingTypesCollection)
        const existingTypesSnapshot = await getDocs(existingTypesQuery)

        if (!existingTypesSnapshot.empty) {
            console.log(`${existingTypesSnapshot.size} clothing types already exist. Skipping seed.`)
            return
        }

        // Add clothing types to Firestore
        for (const clothingType of clothingTypes) {
            await addDoc(clothingTypesCollection, {
                name: clothingType.name,
                category: clothingType.category,
                description: clothingType.description,
                imageUrl: clothingType.imageUrl,
                requiredMeasurements: clothingType.requiredMeasurements,
            })
            console.log(`Added clothing type: ${clothingType.name}`)
        }

        console.log("Successfully seeded clothing types!")
    } catch (error) {
        console.error("Error seeding clothing types:", error)
    }
}
